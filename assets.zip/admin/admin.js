/**
 * Admin Logic
 */

const AdminApp = {
    isAuthenticated: false,
    viewMode: { students: 'table', lectures: 'table' },

    // --- INIT ---
    init() {
        this.checkAuth();
    },

    toggleView(section) {
        this.viewMode[section] = this.viewMode[section] === 'table' ? 'grid' : 'table';
        if (section === 'students') this.loadStudents();
        if (section === 'lectures') {
            if (this.currentCourse) this.renderLecturesList(this.currentCourse.lectures || []);
        }
    },

    checkAuth() {
        const isAuth = sessionStorage.getItem('admin_auth') === 'true';
        const authScreen = document.getElementById('auth-screen');
        const appShell = document.getElementById('app-shell');

        if (isAuth) {
            this.isAuthenticated = true;
            authScreen.classList.add('hidden');
            authScreen.classList.remove('flex');

            appShell.classList.remove('hidden');
            appShell.classList.add('grid-template-columns'); // Restore grid layout if needed
            this.loadDashboard();
        } else {
            authScreen.classList.remove('hidden');
            authScreen.classList.add('flex'); // Ensure it displays

            appShell.classList.add('hidden');
        }
    },

    async login() {
        const pass = document.getElementById('admin-pass').value;
        const err = document.getElementById('auth-error');

        // Hardcoded for simplicity/robustness as requested before
        if (pass === '2862005' || pass === 'admin123') { // Backup + Simple
            sessionStorage.setItem('admin_auth', 'true');
            this.checkAuth();
        } else {
            // Check Server
            try {
                const admins = await DataManager.getAdmins();
                const valid = admins.some(a => a.password === pass);
                if (valid) {
                    sessionStorage.setItem('admin_auth', 'true');
                    this.checkAuth();
                } else {
                    err.classList.remove('hidden');
                }
            } catch (e) {
                alert('خطأ في الاتصال');
            }
        }
    },

    logout() {
        if (confirm('تسجيل خروج؟')) {
            sessionStorage.removeItem('admin_auth');
            location.reload();
        }
    },

    // --- NAV ---
    nav(view) {
        document.querySelectorAll('main > section').forEach(el => el.classList.add('hidden'));
        document.getElementById(`view-${view}`).classList.remove('hidden');

        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        event.currentTarget.classList.add('active'); // Helper to highlight current

        // Close mobile sidebar
        document.querySelector('.sidebar').classList.remove('active');

        if (view === 'dashboard') this.loadDashboard();
        if (view === 'students') this.loadStudents();
        if (view === 'courses') this.loadCourses();
        if (view === 'content') this.prepareContent();
        if (view === 'results') this.loadResults();
        if (view === 'errors') this.loadErrors();
        if (view === 'announcements') this.loadAnnouncements();
    },

    toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('active');
    },

    toggleTheme() {
        const html = document.documentElement;
        const isDark = html.getAttribute('data-theme') === 'dark';
        html.setAttribute('data-theme', isDark ? 'light' : 'dark');
    },

    // --- VIEWS ---
    async loadDashboard() {
        try {
            const [students, courses, results] = await Promise.all([
                DataManager.getStudents(),
                DataManager.getCourses(),
                DataManager.getAllResults()
            ]);

            const stats = [
                { label: 'الطلاب', value: students.length, color: 'info' },
                { label: 'المواد', value: courses.length, color: 'success' },
                { label: 'النتائج', value: results.length, color: 'warning' },
            ];

            document.getElementById('stats-grid').innerHTML = stats.map(s => `
                <div class="stat-card" style="--color: var(--${s.color})">
                    <i class="fas fa-${s.color === 'info' ? 'users' : s.color === 'success' ? 'book' : 'trophy'} stat-icon"></i>
                    <div class="stat-value">${s.value}</div>
                    <div class="stat-label">${s.label}</div>
                </div>
            `).join('');

        } catch (e) { console.error(e); }
    },

    async loadStudents() {
        const wrapper = document.getElementById('students-list').parentElement.parentElement; // table-wrapper
        // We need a stable container. Let's target the parent of table-wrapper or the table-wrapper itself if we replace it.
        // Actually, loadStudents currently targets 'students-list' tbody.
        // We need to take over the whole 'view-students' content or at least the table section.
        // Let's target the 'table-wrapper' div.

        let container = document.querySelector('#view-students .table-wrapper');
        if (!container) container = document.querySelector('#students-list').closest('.table-wrapper');

        // Inject Toggle in Header if missing
        const header = document.querySelector('#view-students .page-header');
        if (header && !document.getElementById('student-view-toggle')) {
            const btn = document.createElement('button');
            btn.id = 'student-view-toggle';
            btn.className = 'btn-secondary rounded-lg px-3 py-2 ml-4'; // Added margin
            btn.onclick = () => this.toggleView('students');
            header.appendChild(btn);
        }

        const toggleBtn = document.getElementById('student-view-toggle');
        if (toggleBtn) {
            toggleBtn.innerHTML = this.viewMode.students === 'table'
                ? '<i class="fas fa-th-large"></i> عرض كروت'
                : '<i class="fas fa-list"></i> عرض جدول';
        }

        container.innerHTML = '<div class="text-center p-4">جاري التحميل...</div>';

        const students = await DataManager.getStudents();

        if (this.viewMode.students === 'table') {
            container.innerHTML = `
                <div class="table-header">
                     <div class="relative">
                        <input type="text" id="search-student" class="admin-input mb-0 w-64" placeholder="بحث..." onkeyup="AdminApp.filterStudents()">
                        <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                    </div>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>الاسم الكامل</th>
                            <th>رقم الهاتف</th>
                            <th>تاريخ التسجيل</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody id="students-list">
                        ${students.map(s => `
                            <tr>
                                <td>${s.name}</td>
                                <td dir="ltr" class="text-right">${s.phone}</td>
                                <td>${new Date(s.joinedAt).toLocaleDateString('ar-EG')}</td>
                                <td>
                                    <button class="btn btn-secondary btn-sm text-indigo-600" onclick="AdminApp.editStudent('${s.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-secondary btn-sm text-blue-600" onclick="AdminApp.emailStudent('${s.id}')" title="مراسلة">
                                        <i class="fas fa-envelope"></i>
                                    </button>
                                    <button class="btn btn-danger btn-sm" onclick="AdminApp.deleteStudent('${s.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } else {
            container.innerHTML = `
                <div class="mb-4 relative">
                    <input type="text" id="search-student" class="admin-input mb-4" placeholder="بحث..." onkeyup="AdminApp.filterStudentsGrid()">
                </div>
                <div id="students-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${students.map(s => `
                        <div class="stat-card flex flex-col gap-3 student-card">
                            <div class="flex items-center gap-3 border-b border-gray-100 pb-3">
                                <div class="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-lg">
                                    ${s.name.charAt(0)}
                                </div>
                                <div>
                                    <h3 class="font-bold text-slate-800">${s.name}</h3>
                                    <span class="text-xs text-slate-500">${new Date(s.joinedAt).toLocaleDateString('ar-EG')}</span>
                                </div>
                            </div>
                            <div class="text-slate-600 font-mono text-sm bg-slate-50 p-2 rounded text-center">
                                ${s.phone}
                            </div>
                            <div class="flex gap-2 mt-auto">
                                <button class="flex-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 py-2 rounded-lg font-bold transition-colors" onclick="AdminApp.editStudent('${s.id}')">
                                    <i class="fas fa-edit"></i> تعديل
                                </button>
                                <button class="flex-1 bg-blue-50 text-blue-600 hover:bg-blue-100 py-2 rounded-lg font-bold transition-colors" onclick="AdminApp.emailStudent('${s.id}')" title="مراسلة">
                                    <i class="fas fa-envelope"></i>
                                </button>
                                 <button class="flex-1 bg-red-50 text-red-600 hover:bg-red-100 py-2 rounded-lg font-bold transition-colors" onclick="AdminApp.deleteStudent('${s.id}')">
                                    <i class="fas fa-trash"></i> حذف
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
    },

    filterStudentsGrid() {
        const q = document.getElementById('search-student').value.toLowerCase();
        document.querySelectorAll('.student-card').forEach(card => {
            card.style.display = card.textContent.toLowerCase().includes(q) ? 'flex' : 'none';
        });
    },

    async deleteStudent(id) {
        if (confirm('حذف الطالب؟')) {
            await DataManager.deleteStudent(id);
            this.loadStudents();
        }
    },

    async editStudent(id) {
        const students = await DataManager.getStudents();
        const student = students.find(s => s.id === id);
        if (!student) return;

        const newName = prompt('تعديل الاسم:', student.name);
        if (newName === null) return; // Cancelled
        const newPhone = prompt('تعديل رقم الهاتف:', student.phone);
        if (newPhone === null) return;

        if (newName && newPhone) {
            await DataManager.updateStudent({ id, name: newName, phone: newPhone });
            this.loadStudents();
        }
    },

    async removeDuplicates() {
        if (!confirm('سيتم فحص جميع الطلاب وحذف الحسابات المكررة (نفس رقم الهاتف) والإبقاء على الأحدث. هل أنت متأكد؟')) return;

        const students = await DataManager.getStudents();
        const unique = new Map();
        let duplicatesCount = 0;

        // Group by phone
        students.forEach(s => {
            if (!unique.has(s.phone)) {
                unique.set(s.phone, s);
            } else {
                duplicatesCount++;
                // Keep the one with latest ID (assuming ID is timestamp or similar, or just keep first found)
                // Actually user requested "remove duplicates", usually keeping the oldest or newest. 
                // Let's keep the one already in map (first encountered) or update if needed.
                // Simple approach: Delete the current one 's' if map already has phone.
                DataManager.deleteStudent(s.id);
            }
        });

        alert(`تم حذف ${duplicatesCount} حساب مكرر.`);
        this.loadStudents();
    },

    filterStudents() {
        const q = document.getElementById('search-student').value.toLowerCase();
        document.querySelectorAll('#students-list tr').forEach(row => {
            row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
        });
    },

    async loadCourses() {
        const list = document.getElementById('courses-list');
        list.innerHTML = '<p class="text-center p-4">جاري التحميل...</p>';
        const courses = await DataManager.getCourses();

        list.innerHTML = courses.map(c => {
            const lecturesCount = c.lectures ? c.lectures.length : 0;
            return `
            <div class="course-card group relative bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all border border-slate-100">
                <div class="absolute top-4 left-4 bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold">
                    ${lecturesCount} محاضرة
                </div>
                <div class="mb-4 text-4xl mb-6">📚</div>
                <h3 class="text-xl font-bold text-slate-800 mb-2">${c.title}</h3>
                <p class="text-slate-500 text-sm mb-6 line-clamp-2">${c.description || 'لا يوجد وصف'}</p>
                
                <div class="flex gap-2 mt-auto">
                    <button class="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-bold transition-colors shadow-indigo-200 shadow-lg"
                            onclick="AdminApp.manageCourse('${c.id}')">
                        <i class="fas fa-layer-group ml-2"></i> إدارة المحتوى
                    </button>
                    <button class="bg-gray-100 hover:bg-gray-200 text-gray-600 py-2 px-3 rounded-lg font-bold transition-colors"
                            onclick="AdminApp.editCourse('${c.id}')" title="تعديل الاسم/الوصف">
                        <i class="fas fa-edit"></i>
                    </button>
                     <button class="bg-red-50 hover:bg-red-100 text-red-600 py-2 px-3 rounded-lg font-bold transition-colors"
                            onclick="AdminApp.deleteCourse('${c.id}')" title="حذف المادة">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            `;
        }).join('');
    },

    async editCourse(id) {
        const course = await DataManager.getCourseById(id);
        if (!course) return;

        const newTitle = prompt('تعديل اسم المادة:', course.title);
        if (newTitle === null) return;

        const newDesc = prompt('تعديل وصف المادة:', course.description || '');
        if (newDesc === null) return;

        if (newTitle || newDesc) {
            await DataManager.saveCourse({
                ...course,
                title: newTitle || course.title,
                description: newDesc || course.description
            });
            this.loadCourses();
        }
    },

    async addCourse() {
        const title = document.getElementById('new-course-title').value;
        const desc = document.getElementById('new-course-desc').value;
        if (!title) return;

        await DataManager.saveCourse({ title, description: desc });
        document.getElementById('new-course-title').value = '';
        this.loadCourses();
    },

    async deleteCourse(id) {
        if (confirm('حذف المادة؟')) {
            await DataManager.deleteCourse(id);
            this.loadCourses();
        }
    },

    async prepareContent() {
        const select = document.getElementById('content-course-select');
        const courses = await DataManager.getCourses();
        select.innerHTML = courses.map(c => `<option value="${c.id}">${c.title}</option>`).join('');
        this.toggleMainContentType(); // Initialize state

        // Init Content Editor if not exists
        if (!this.contentEditor) {
            this.contentEditor = CodeMirror.fromTextArea(document.getElementById('content-code'), {
                mode: "application/json",
                theme: "dracula",
                lineNumbers: true,
                matchBrackets: true,
                autoCloseBrackets: true,
                tabSize: 2,
                lint: true
            });
            this.contentEditor.on('change', (cm) => {
                document.getElementById('content-code').value = cm.getValue();
            });
            // Default value
            this.contentEditor.setValue('{\n  "title": "Exam Title",\n  "questions": [\n    ...\n  ]\n}');
        }
        // Refresh to ensure proper rendering if it was hidden
        setTimeout(() => this.contentEditor.refresh(), 100);
    },

    toggleMainContentType() {
        const type = document.querySelector('input[name="mainContentType"]:checked').value;
        if (type === 'lesson') {
            document.getElementById('main-content-lesson-inputs').classList.remove('hidden');
            document.getElementById('main-content-exam-inputs').classList.add('hidden');
        } else {
            document.getElementById('main-content-lesson-inputs').classList.add('hidden');
            document.getElementById('main-content-exam-inputs').classList.remove('hidden');
            if (this.contentEditor) setTimeout(() => this.contentEditor.refresh(), 100);
        }
    },

    async updateContentChapterSelect() {
        const courseId = document.getElementById('content-course-select').value;
        const chapterSelect = document.getElementById('content-chapter-select');
        chapterSelect.innerHTML = '<option value="">-- بدون فصل --</option>';

        if (!courseId) return;

        const course = await DataManager.getCourseById(courseId);
        if (course && course.chapters) {
            course.chapters.forEach(ch => {
                const opt = document.createElement('option');
                opt.value = ch.id;
                opt.innerText = ch.title;
                chapterSelect.appendChild(opt);
            });
        }
    },

    async addContent() {
        const courseId = document.getElementById('content-course-select').value;
        const chapterId = document.getElementById('content-chapter-select').value;
        const type = document.querySelector('input[name="mainContentType"]:checked').value;
        const title = document.getElementById('content-title').value;

        if (!title || !courseId) return alert('البيانات الأساسية مطلوبة (المادة والعنوان)');

        let video = '', pdf = '', code = '';

        if (type === 'lesson') {
            video = document.getElementById('content-video').value;
            pdf = document.getElementById('content-pdf').value;
        } else {
            // Get value from editor
            code = this.contentEditor ? this.contentEditor.getValue() : document.getElementById('content-code').value;
            // Validate JSON before saving
            try {
                JSON.parse(code);
            } catch (e) {
                return alert('⚠️ كود الامتحان للحفظ يجب أن يكون بصيغة JSON صحيحة');
            }
        }

        const lecture = {
            id: Date.now().toString(),
            title,
            videoUrl: video,
            attachmentUrl: pdf,
            interactiveCode: code,
            type: type
        };

        await DataManager.addLectureToCourse(courseId, lecture, chapterId);

        alert('✅ تم نشر المحتوى بنجاح!');
        // Reset Form
        document.getElementById('content-title').value = '';
        document.getElementById('content-video').value = '';
        document.getElementById('content-pdf').value = '';
        if (this.contentEditor) this.contentEditor.setValue('{\n  "title": "",\n  "questions": []\n}');
    },

    async loadResults() {
        const tbody = document.getElementById('results-list');
        // Replace with getResults if available, or getAllResults
        const results = await DataManager.getAllResults();
        tbody.innerHTML = results.map(r => `
            <tr>
                <td>${r.studentName || 'غير معروف'}</td>
                <td>${r.examTitle || '-'}</td>
                <td>${r.score}%</td>
                <td>${new Date(r.date || Date.now()).toLocaleDateString('ar-EG')}</td>
                <td>
                     <button class="text-red-500 hover:text-red-700" onclick="AdminApp.deleteResult('${r.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    },

    async deleteResult(id) {
        if (confirm('حذف هذه النتيجة؟')) {
            await DataManager.deleteResult(id);
            this.loadResults();
        }
    },

    async loadErrors() {
        const tbody = document.getElementById('errors-list');
        tbody.innerHTML = '<tr><td colspan="6" class="text-center p-4">جاري التحميل...</td></tr>';

        try {
            const errors = await DataManager.getErrors();

            if (!errors || Object.keys(errors).length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center p-4">سجل الأخطاء نظيف ممتاز! 🎉</td></tr>';
                return;
            }

            const list = Array.isArray(errors) ? errors : Object.values(errors);

            tbody.innerHTML = list.map(e => `
                <tr class="bg-red-50/50">
                    <td class="font-bold">${e.studentName || '-'}</td>
                    <td>${e.examTitle || '-'}</td>
                    <td class="max-w-xs truncate" title="${e.question}">${e.question}</td>
                    <td class="text-red-600 font-bold">${e.wrongAnswer}</td>
                    <td class="text-green-600 font-bold">${e.correctAnswer}</td>
                    <td class="text-sm text-gray-600 max-w-xs truncate" title="${e.explanation}">${e.explanation}</td>
                </tr>
            `).join('');
        } catch (err) {
            console.error(err);
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-red-500">حدث خطأ في جلب البيانات</td></tr>';
        }
    },
    // --- ANNOUNCEMENTS ---
    async loadAnnouncements() {
        const tbody = document.getElementById('announcements-list');
        tbody.innerHTML = '<tr><td colspan="4" class="text-center p-4">جاري التحميل...</td></tr>';

        try {
            const ads = await DataManager.getAnnouncements(); // Need to impl in DataManager
            if (!ads || ads.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="text-center p-4">لا توجد إعلانات نشطة</td></tr>';
                return;
            }

            tbody.innerHTML = ads.map(ad => `
                <tr>
                    <td><img src="${ad.image}" class="w-16 h-10 object-cover rounded border border-gray-200" alt="Ad"></td>
                    <td class="text-xs font-mono text-slate-500 max-w-xs truncate" title="${ad.link}">${ad.link || '-'}</td>
                    <td class="text-sm font-bold text-slate-700">${new Date(ad.endDate).toLocaleDateString('ar-EG')} <span class="text-xs text-slate-400">(${this.getDaysLeft(ad.endDate)} يوم)</span></td>
                    <td>
                        <button class="text-red-500 hover:text-red-700 bg-red-50 p-2 rounded" onclick="AdminApp.deleteAnnouncement('${ad.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        } catch (e) {
            console.error(e);
            tbody.innerHTML = '<tr><td colspan="4" class="text-center p-4 text-red-500">حدث خطأ</td></tr>';
        }
    },

    getDaysLeft(dateStr) {
        const diff = new Date(dateStr) - new Date();
        return Math.ceil(diff / (1000 * 60 * 60 * 24));
    },

    async addAnnouncement() {
        const img = document.getElementById('new-ad-image').value;
        const link = document.getElementById('new-ad-link').value;
        const duration = parseInt(document.getElementById('new-ad-duration').value) || 3;

        if (!img) return alert('صورة الإعلان مطلوبة');

        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(startDate.getDate() + duration);

        const ad = {
            id: Date.now().toString(),
            image: img,
            link: link,
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString(),
            active: true
        };

        await DataManager.addAnnouncement(ad);
        document.getElementById('new-ad-image').value = '';
        document.getElementById('new-ad-link').value = '';
        this.loadAnnouncements();
    },

    async deleteAnnouncement(id) {
        if (confirm('حذف الإعلان؟')) {
            await DataManager.deleteAnnouncement(id);
            this.loadAnnouncements();
        }
    },

    // --- MESSAGES / EMAILS ---
    async sendMassEmail() {
        const subject = document.getElementById('msg-subject').value;
        const body = document.getElementById('msg-body').value;

        if (!subject || !body) return alert('الرجاء كتابة العنوان ونص الرسالة');

        const students = await DataManager.getStudents();
        const emails = students
            .map(s => s.email)
            .filter(e => e && e.includes('@') && e !== 'null' && e !== 'undefined');

        if (emails.length === 0) return alert('لا توجد عناوين بريد إلكتروني مسجلة للطلاب');

        // Create mailto link with BCC
        const bcc = emails.join(',');
        const mailtoLink = `mailto:?bcc=${bcc}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

        window.open(mailtoLink, '_blank');
    },

    async emailStudent(id) {
        const students = await DataManager.getStudents();
        const student = students.find(s => s.id === id);

        if (!student || !student.email || !student.email.includes('@')) {
            return alert('هذا الطالب ليس لديه بريد إلكتروني مسجل');
        }

        const subject = encodeURIComponent('رسالة من إدارة منصة الخطة');
        window.open(`mailto:${student.email}?subject=${subject}`, '_blank');
    },

    // --- COURSE MANAGER ---
    async addChapterPrompt() {
        const title = prompt('أدخل عنوان الفصل الجديد:');
        if (title && this.currentCourse) {
            await DataManager.addChapter(this.currentCourse.id, title);
            this.manageCourse(this.currentCourse.id); // Reload
        }
    },

    async manageCourse(id) {
        this.nav('course-manager');
        const course = await DataManager.getCourseById(id);
        if (!course) return alert('المادة غير موجودة');

        this.currentCourse = course; // Store state

        // Populate Info
        document.getElementById('edit-course-id').value = course.id;
        document.getElementById('edit-course-title').value = course.title;
        document.getElementById('edit-course-desc').value = course.description || '';
        document.getElementById('manager-course-title').innerText = `إدارة: ${course.title}`;

        // Populate Lectures & Chapters
        this.renderLecturesList(course);
    },

    renderLecturesList(course) {
        const container = document.getElementById('manager-lectures-container');
        if (!container) return;

        let html = '';

        // 1. Render Chapters Grouped
        if (course.chapters && course.chapters.length > 0) {
            html += course.chapters.map(ch => `
                <div class="mb-6 border border-slate-200 rounded-lg overflow-hidden">
                    <div class="bg-indigo-50 p-4 flex justify-between items-center cursor-pointer hover:bg-indigo-100" 
                         onclick="this.nextElementSibling.classList.toggle('hidden')">
                        <h4 class="font-bold text-indigo-800"><i class="fas fa-folder-open ml-2"></i> ${ch.title}</h4>
                        <div class="flex gap-2">
                             <span class="text-xs bg-white px-2 py-1 rounded text-indigo-600 font-bold">${(ch.lectures || []).length} محتوى</span>
                             <button class="text-red-500 hover:text-red-700 px-2" onclick="event.stopPropagation(); AdminApp.deleteChapter('${ch.id}')"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                    <div class="p-4 bg-white transition-all">
                        ${this.renderLecturesTableOrGrid(ch.lectures || [], ch.id)}
                    </div>
                </div>
            `).join('');
        }

        // 2. Render Root Lectures
        if (course.lectures && course.lectures.length > 0) {
            html += `
                <div class="mb-6 border border-slate-200 rounded-lg overflow-hidden">
                    <div class="bg-gray-50 p-4 font-bold text-gray-700">
                        <i class="fas fa-folder ml-2"></i> محتوى عام (بدون فصل)
                    </div>
                    <div class="p-4 bg-white">
                        ${this.renderLecturesTableOrGrid(course.lectures, null)}
                    </div>
                </div>
             `;
        }

        if (html === '') {
            html = '<div class="text-center p-8 text-gray-500">لا يوجد محتوى بعد. أضف فصولاً أو محاضرات.</div>';
        }

        container.innerHTML = html;
    },

    renderLecturesTableOrGrid(lectures, chapterId) {
        if (!lectures || lectures.length === 0) return '<div class="text-sm text-gray-400 p-2">لا يوجد محتوى في هذا القسم</div>';

        // Reuse existing logic but simplified for embedding
        return `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
             ${lectures.map(l => `
                <div class="stat-card flex flex-col gap-2 p-3 border border-slate-100 shadow-sm relative group">
                    <div class="flex justify-between items-start">
                        <h5 class="font-bold text-slate-800">${l.title}</h5>
                         <span class="text-xs px-2 py-0.5 rounded ${l.type === 'exam' ? 'bg-indigo-100 text-indigo-700' : 'bg-teal-100 text-teal-700'}">
                            ${l.type === 'exam' ? 'امتحان' : 'فيديو'}
                        </span>
                    </div>
                    <div class="flex gap-2 mt-2 pt-2 border-t border-slate-50">
                            <button class="text-indigo-600 hover:bg-indigo-50 px-2 py-1 rounded text-sm" onclick="AdminApp.editLectureData('${l.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                            <button class="text-red-600 hover:bg-red-50 px-2 py-1 rounded text-sm" onclick="AdminApp.deleteLecture('${l.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `).join('')}
        </div>
        `;
    },

    async deleteChapter(id) {
        if (confirm('حذف الفصل وكل محتوياته؟ هذا الإجراء لا يمكن التراجع عنه.')) {
            await DataManager.deleteChapter(this.currentCourse.id, id);
            this.manageCourse(this.currentCourse.id);
        }
    },

    async updateCourseInfo() {
        const id = document.getElementById('edit-course-id').value;
        const title = document.getElementById('edit-course-title').value;
        const desc = document.getElementById('edit-course-desc').value;

        await DataManager.saveCourse({ id, title, description: desc });
        alert('تم تحديث بيانات المادة');
        this.manageCourse(id); // Reload
    },

    // Lecture Modal
    showAddLectureModal() {
        document.getElementById('lecture-form-container').classList.remove('hidden');
        document.getElementById('lecture-form-title').innerText = '✨ إضافة محتوى جديد (محاضرة/امتحان)';

        // Reset Fields
        document.getElementById('edit-lecture-id').value = '';
        document.getElementById('edit-lecture-title').value = '';
        document.getElementById('edit-lecture-video').value = '';
        document.getElementById('edit-lecture-pdf').value = '';
        document.getElementById('edit-lecture-code').value = '';
        document.getElementById('edit-exam-title').value = '';

        // Populate Chapter Select (if in Course Manager)
        const chapterSelect = document.getElementById('edit-lecture-chapter');
        chapterSelect.innerHTML = '<option value="">-- بدون فصل (عام) --</option>';
        if (this.currentCourse && this.currentCourse.chapters) {
            this.currentCourse.chapters.forEach(ch => {
                const opt = document.createElement('option');
                opt.value = ch.id;
                opt.innerText = ch.title;
                chapterSelect.appendChild(opt);
            });
        }

        // Init CodeMirror if not exists
        if (!this.examEditor) {
            this.examEditor = CodeMirror.fromTextArea(document.getElementById('edit-lecture-code'), {
                mode: "application/json",
                theme: "dracula",
                lineNumbers: true,
                matchBrackets: true,
                autoCloseBrackets: true,
                tabSize: 2,
                lint: true
            });

            this.examEditor.on('change', (cm) => {
                const val = cm.getValue();
                document.getElementById('edit-lecture-code').value = val; // Sync to textarea
                this.validateExamJSON(val);
            });
        }

        this.examEditor.setValue('{\n  "title": "Exam Title",\n  "questions": [\n    {\n      "q": "Question 1?",\n      "options": ["A", "B", "C", "D"],\n      "answer": "A",\n      "explanation": "Why..."\n    }\n  ]\n}');

        // Reset Type to Lesson
        const radios = document.getElementsByName('lectureType');
        if (radios.length > 0) radios[0].checked = true; // Select Lesson
        this.toggleLectureType(); // Trigger UI update

        // Scroll to form
        document.getElementById('lecture-form-container').scrollIntoView({ behavior: 'smooth' });
    },

    hideLectureForm() {
        document.getElementById('lecture-form-container').classList.add('hidden');
    },

    validateExamJSON(jsonStr) {
        const preview = document.getElementById('json-preview');
        const status = document.getElementById('editor-status');

        try {
            const obj = JSON.parse(jsonStr);
            status.innerHTML = '<span class="text-green-600">✅ JSON صحيح (Valid)</span>';
            preview.textContent = JSON.stringify(obj, null, 2);
            preview.classList.remove('border-red-500');
            preview.classList.add('border-green-500');
        } catch (e) {
            status.innerHTML = `<span class="text-red-600">❌ خطأ في التنسيق: ${e.message}</span>`;
            preview.textContent = "Waiting for valid JSON...";
            preview.classList.add('border-red-500');
            preview.classList.remove('border-green-500');
        }
    },

    editLectureData(lectureId) {
        if (!this.currentCourse) return;

        // Find lecture in root or chapters
        let lecture = (this.currentCourse.lectures || []).find(l => l.id === lectureId);
        let chapterId = '';

        if (!lecture && this.currentCourse.chapters) {
            for (const ch of this.currentCourse.chapters) {
                const found = (ch.lectures || []).find(l => l.id === lectureId);
                if (found) {
                    lecture = found;
                    chapterId = ch.id;
                    break;
                }
            }
        }

        if (!lecture) return;

        this.showAddLectureModal();
        document.getElementById('lecture-form-title').innerText = '✏️ تعديل محاضرة';
        document.getElementById('edit-lecture-id').value = lecture.id;
        document.getElementById('edit-lecture-chapter').value = chapterId; // Set Chapter

        if (lecture.type === 'exam' || lecture.interactiveCode) {
            document.querySelector('input[name="lectureType"][value="exam"]').checked = true;
            document.getElementById('edit-exam-title').value = lecture.title;
            // Set Editor Value
            if (this.examEditor) {
                // If interactiveCode parses as JSON, format it. Else show as string.
                try {
                    const json = JSON.parse(lecture.interactiveCode);
                    this.examEditor.setValue(JSON.stringify(json, null, 2));
                } catch (e) {
                    this.examEditor.setValue(lecture.interactiveCode || '');
                }
            }
        } else {
            document.querySelector('input[name="lectureType"][value="lesson"]').checked = true;
            document.getElementById('edit-lecture-title').value = lecture.title;
            document.getElementById('edit-lecture-video').value = lecture.videoUrl || '';
            document.getElementById('edit-lecture-pdf').value = lecture.attachmentUrl || '';
        }

        this.toggleLectureType();
    },

    // Toggle Logic
    toggleLectureType() {
        const type = document.querySelector('input[name="lectureType"]:checked').value;
        if (type === 'lesson') {
            document.getElementById('type-lesson-inputs').classList.remove('hidden');
            document.getElementById('type-exam-inputs').classList.add('hidden');
        } else {
            document.getElementById('type-lesson-inputs').classList.add('hidden');
            document.getElementById('type-exam-inputs').classList.remove('hidden');
            // Refresh editor to solve rendering issues when hidden
            if (this.examEditor) setTimeout(() => this.examEditor.refresh(), 100);
        }
    },

    // Save Logic Update
    async saveLecture() {
        const courseId = document.getElementById('edit-course-id').value;
        const id = document.getElementById('edit-lecture-id').value;

        // Determine Type
        const type = document.querySelector('input[name="lectureType"]:checked').value;

        let title, video = '', pdf = '', code = '';

        if (type === 'lesson') {
            title = document.getElementById('edit-lecture-title').value;
            video = document.getElementById('edit-lecture-video').value;
            pdf = document.getElementById('edit-lecture-pdf').value;
        } else {
            title = document.getElementById('edit-exam-title').value;
            // Get value directly from editor if initialized
            code = this.examEditor ? this.examEditor.getValue() : document.getElementById('edit-lecture-code').value;

            // Validate JSON before saving
            try {
                JSON.parse(code);
            } catch (e) {
                return alert('⚠️ كود الامتحان للحفظ يجب أن يكون بصيغة JSON صحيحة');
            }
        }

        if (!title) return alert('العنوان مطلوب');

        const lectureData = {
            id: id || Date.now().toString(),
            title,
            videoUrl: video,
            attachmentUrl: pdf,
            interactiveCode: code,
            type: type // Save Type
        };

        if (id) {
            await DataManager.updateLecture(courseId, lectureData);
        } else {
            await DataManager.addLectureToCourse(courseId, lectureData);
        }

        this.hideLectureForm();
        this.manageCourse(courseId); // Reload UI
    },

    async deleteLecture(lectureId) {
        if (!confirm('حذف المحاضرة؟')) return;
        const courseId = document.getElementById('edit-course-id').value;
        await DataManager.deleteLecture(courseId, lectureId);
    }
};

document.addEventListener('DOMContentLoaded', () => AdminApp.init());
window.AdminApp = AdminApp;
