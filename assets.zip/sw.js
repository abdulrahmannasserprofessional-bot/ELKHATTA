const CACHE_NAME = 'plan-platform-v1';
const ASSETS = [
    './',
    './index.html',
    './css/main.css',
    './js/data_manager.js',
    './student/index.html',
    './student/student.css',
    './student/student.js',
    './admin/index.html',
    './admin/admin.css',
    './admin/admin.js'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
    );
});

self.addEventListener('fetch', (e) => {
    e.respondWith(
        caches.match(e.request).then((res) => res || fetch(e.request))
    );
});
