/**
 * Student App Logic - Premium Design
 */

const StudentApp = {
    user: null,

    async init() {
        this.checkAuth();
        if (this.isAuthenticated) {
            await this.loadCourses(); // Wait for courses
            this.loadAnnouncements();

            // Check URL Params for deep linking / state restoration
            const params = new URLSearchParams(window.location.search);
            const courseId = params.get('course');
            const lectureId = params.get('lecture');

            if (courseId) {
                await this.openCourse(courseId);
                if (lectureId && this.currentCourse) {
                    setTimeout(() => {
                        // Find lecture in root or chapters
                        let lecture = (this.currentCourse.lectures || []).find(l => l.id === lectureId);
                        if (!lecture && this.currentCourse.chapters) {
                            for (const ch of this.currentCourse.chapters) {
                                const found = (ch.lectures || []).find(l => l.id === lectureId);
                                if (found) { lecture = found; break; }
                            }
                        }

                        if (lecture) this.openLecture(lectureId);
                    }, 500);
                }
            }
        }
    },

    get isAuthenticated() {
        return !!this.user;
    },

    checkAuth() {
        this.user = DataManager.getSession();
        if (this.isAuthenticated) {
            this.showApp();
        } else {
            document.getElementById('auth-container').classList.remove('hidden');
            document.getElementById('app-shell').classList.add('hidden');
        }
    },

    toggleAuthMode() {
        document.getElementById('auth-container').classList.toggle('sign-up-mode');
    },

    async login() {
        const phone = document.getElementById('student-phone').value;
        if (!phone) return alert('أدخل رقم الهاتف');

        const res = await DataManager.loginStudent(phone);
        if (res.success) {
            this.showApp();
        } else {
            alert(res.message);
        }
    },

    async register() {
        const name = document.getElementById('reg-name').value;
        const phone = document.getElementById('reg-phone').value;
        const email = document.getElementById('reg-email').value;

        if (!name || !phone || !email) return alert('جميع البيانات مطلوبة');

        const res = await DataManager.saveStudent({ name, phone, email });
        if (res.success) {
            alert('تم التسجيل! قم بتسجيل الدخول الآن.');
            this.toggleAuthMode();
        } else {
            alert(res.message);
        }
    },

    logout() {
        DataManager.logout();
    },

    showApp() {
        this.user = DataManager.getSession();

        // DEBUG: Check user object
        // alert('User User: ' + JSON.stringify(this.user));

        document.getElementById('auth-container').classList.add('hidden');
        document.getElementById('app-shell').classList.remove('hidden');
        document.getElementById('user-name').innerText = this.user.name;

        // CHECK FOR MISSING EMAIL (Robust check)
        const email = this.user.email;

        // Remove debug alert
        // alert(`DEBUG EMAIL: "${email}" (Type: ${typeof email})`); 

        if (!email || (typeof email === 'string' && email.trim() === '') || email === 'null' || email === 'undefined') {
            console.log('Email missing, triggering prompt...');
            // Temporary debug to confirm we are here
            // alert('DEBUG: Email is missing, attempting to show modal...');
            setTimeout(() => this.showEmailPrompt(), 500);
        }

        this.nav('courses');
    },

    // --- EMAIL COLLECTION FOR LEGACY USERS ---
    showEmailPrompt() {
        const modalHtml = `
            <div id="email-prompt-modal" class="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 fade-in">
                <div class="bg-white rounded-2xl p-8 w-full max-w-md text-center shadow-2xl relative overflow-hidden">
                    <div class="absolute top-0 left-0 w-full h-2 bg-indigo-600"></div>
                    <div class="mb-6">
                        <div class="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-envelope text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-slate-800 mb-2">تحديث البيانات مطلوب</h3>
                        <p class="text-slate-500">لضمان وصول الإشعارات ونتائج الامتحانات، يرجى إضافة بريدك الإلكتروني.</p>
                    </div>
                    
                    <div class="text-right mb-4">
                        <label class="block text-sm font-bold text-slate-700 mb-2">البريد الإلكتروني</label>
                        <input type="email" id="missing-email-input" class="w-full p-3 border-2 border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-none transition-colors text-left" dir="ltr" placeholder="example@gmail.com">
                        <p id="email-error" class="text-red-500 text-sm mt-1 hidden"></p>
                    </div>

                    <button onclick="StudentApp.saveMissingEmail()" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg hover:shadow-indigo-500/30">
                        حفظ ومتابعة
                    </button>
                    <p class="text-xs text-slate-400 mt-4"><i class="fas fa-lock ml-1"></i> بياناتك آمنة ولن يتم مشاركتها.</p>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    async saveMissingEmail() {
        const emailInput = document.getElementById('missing-email-input');
        const errorMsg = document.getElementById('email-error');
        const email = emailInput.value.trim();

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!email || !emailRegex.test(email)) {
            errorMsg.innerText = 'يرجى إدخال بريد إلكتروني صحيح';
            errorMsg.classList.remove('hidden');
            emailInput.classList.add('border-red-500');
            return;
        }

        // Update UI state
        const btn = document.querySelector('#email-prompt-modal button');
        const originalText = btn.innerText;
        btn.innerText = 'جاري الحفظ...';
        btn.disabled = true;

        try {
            // Update in DB
            this.user.email = email;
            const res = await DataManager.updateStudent({ id: this.user.id, email: email });

            if (res.success) {
                // Update Session
                DataManager.setSession(this.user);

                // Remove Modal
                document.getElementById('email-prompt-modal').remove();
                alert('✅ تم تحديث بياناتك بنجاح!');
            } else {
                throw new Error(res.message || 'فشل التحديث');
            }
        } catch (e) {
            console.error(e);
            errorMsg.innerText = 'حدث خطأ أثناء الحفظ، حاول مرة أخرى';
            errorMsg.classList.remove('hidden');
            btn.innerText = originalText;
            btn.disabled = false;
        }
    },

    // --- Navigation ---
    nav(view) {
        document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
        const target = document.getElementById(`view-${view}`);
        if (target) target.classList.remove('hidden');
        window.scrollTo(0, 0);

        if (view === 'courses') this.loadCourses();
    },

    // --- ANNOUNCEMENTS ---
    async loadAnnouncements() {
        const slider = document.getElementById('announcements-slider');
        try {
            const ads = await DataManager.getAnnouncements();
            if (!ads || ads.length === 0) {
                slider.classList.add('hidden');
                return;
            }

            const activeAds = ads.filter(ad => {
                return ad.active && new Date(ad.endDate) > new Date();
            });

            if (activeAds.length === 0) {
                slider.classList.add('hidden');
                return;
            }

            slider.classList.remove('hidden');
            slider.innerHTML = activeAds.map(ad => `
                <div class="inline-block w-80 mr-4 relative rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow cursor-pointer" 
                    onclick="window.open('${ad.link || '#'}', '_blank')">
                    <img src="${ad.image}" class="w-full h-40 object-cover" alt="Announcement">
                </div>
            `).join('');

        } catch (e) { console.error('Ads Error', e); }
    },

    async loadCourses() {
        const grid = document.getElementById('courses-grid');
        grid.innerHTML = '<div class="col-span-full text-center p-8">جاري التحميل...</div>';
        const courses = await DataManager.getCourses();

        if (courses.length === 0) {
            grid.innerHTML = '<div class="col-span-full text-center p-8 text-slate-500">لا توجد مواد دراسية حالياً.</div>';
            return;
        }

        grid.innerHTML = courses.map(c => `
            <div class="course-card fade-in" onclick="StudentApp.openCourse('${c.id}')">
                <div class="course-cover">
                    <div class="course-icon">📚</div>
                </div>
                <div class="course-info">
                    <h3>${c.title}</h3>
                    <p>${c.description || 'رحلة التفوق تبدأ هنا'}</p>
                    <div style="margin-top: 10px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.8rem; color: var(--primary); font-weight: bold;">
                            ${c.lectures?.length || 0} محاضرات
                        </span>
                        <i class="fas fa-arrow-left" style="color: var(--border);"></i>
                    </div>
                </div>
            </div>
        `).join('');
    },

    async openCourse(id) {
        // Update URL
        const url = new URL(window.location);
        url.searchParams.set('course', id);
        url.searchParams.delete('lecture');
        window.history.pushState({}, '', url);

        const courses = await DataManager.getCourses();
        this.currentCourse = courses.find(c => c.id === id);
        if (!this.currentCourse) return;

        const titleEl = document.getElementById('course-title');
        if (titleEl) titleEl.innerText = this.currentCourse.title;

        const descEl = document.getElementById('course-desc');
        if (descEl) descEl.innerText = this.currentCourse.description || '';

        const list = document.getElementById('lectures-list');
        list.innerHTML = '';
        let html = '';

        // 1. Render Chapters
        if (this.currentCourse.chapters && this.currentCourse.chapters.length > 0) {
            html += this.currentCourse.chapters.map((ch, idx) => `
                <div class="chapter-item mb-4 rounded-xl overflow-hidden border border-slate-100 shadow-sm">
                    <div class="chapter-header bg-indigo-50 p-4 cursor-pointer flex justify-between items-center"
                         onclick="this.nextElementSibling.classList.toggle('hidden'); this.querySelector('.fa-chevron-down').classList.toggle('rotate-180')">
                        <h4 class="font-bold text-indigo-800 text-lg">${ch.title}</h4>
                        <i class="fas fa-chevron-down text-indigo-400 transition-transform duration-300"></i>
                    </div>
                    <div class="chapter-content p-2 bg-white transition-all">
                        ${(ch.lectures || []).map((l, i) => this.renderLectureItem(l, i + 1)).join('')}
                        ${(!ch.lectures || ch.lectures.length === 0) ? '<p class="text-sm text-slate-400 p-2 text-center">لا يوجد محتوى</p>' : ''}
                    </div>
                </div>
            `).join('');
        }

        // 2. Render Root Lectures
        if (this.currentCourse.lectures && this.currentCourse.lectures.length > 0) {
            // If we have chapters, add a header for root content
            if (html !== '') {
                html += `<h4 class="font-bold text-slate-700 mt-6 mb-3 px-2">محتوى عام</h4>`;
            }
            html += (this.currentCourse.lectures || []).map((l, i) => this.renderLectureItem(l, i + 1)).join('');
        }

        if (html === '') html = '<div class="text-center p-8 text-slate-500">جاري إضافة المحتوى لهذا الكورس...</div>';

        list.innerHTML = html;
        this.nav('course-details');
    },

    renderLectureItem(l, index) {
        return `
            <div class="lecture-item fade-in mb-2 p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors border-b border-slate-50 last:border-0" 
                 onclick="StudentApp.openLecture('${l.id}')">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="width: 30px; height: 30px; background: #e0e7ff; color: var(--primary); border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold;">${index}</div>
                    <div>
                        <h4 style="font-weight: 700; margin-bottom: 2px;">${l.title}</h4>
                        <span style="font-size: 0.8rem; color: var(--text-muted);">${l.type === 'exam' ? '⚡ امتحان' : '📺 فيديو'}</span>
                    </div>
                </div>
                <div style="width: 32px; height: 32px; border-radius: 50%; border: 1px solid var(--border); display: flex; justify-content: center; align-items: center;">
                    <i class="fas fa-play" style="font-size: 0.8rem; color: var(--primary); margin-left: 2px;"></i>
                </div>
            </div>
        `;
    },

    openLecture(id) {
        // Update URL
        const url = new URL(window.location);
        url.searchParams.set('lecture', id);
        window.history.pushState({}, '', url);

        // Find lecture (Root or Nested)
        let lecture = (this.currentCourse.lectures || []).find(l => l.id === id);
        if (!lecture && this.currentCourse.chapters) {
            for (const ch of this.currentCourse.chapters) {
                const found = (ch.lectures || []).find(l => l.id === id);
                if (found) { lecture = found; break; }
            }
        }

        if (!lecture) return alert(' المحتوى غير موجود');
        this.currentLecture = lecture;
        document.getElementById('lecture-title').innerText = this.currentLecture.title;

        const container = document.querySelector('.video-container');
        container.innerHTML = '';
        container.className = 'video-container';

        const btnPdf = document.getElementById('btn-pdf');
        const btnExam = document.getElementById('btn-exam');

        if (this.currentLecture.type === 'exam' || this.currentLecture.interactiveCode) {
            // Check if JSON
            let examData = null;
            try {
                // Determine if it's JSON (starts with { or [)
                const code = this.currentLecture.interactiveCode ? this.currentLecture.interactiveCode.trim() : '';
                if (code.startsWith('{') || code.startsWith('[')) {
                    examData = JSON.parse(code);
                }
            } catch (e) {
                console.log('Not JSON, falling back to HTML');
            }

            if (examData) {
                // RENDER NATIVE QUIZ
                container.classList.remove('exam-mode');
                container.classList.add('native-quiz-mode'); // Remove black background
                this.renderQuiz(container, examData);
            } else {
                // RENDER IFRAME / HTML
                container.classList.add('exam-mode');
                container.innerHTML = this.currentLecture.interactiveCode || '<div class="text-center p-8 text-white">كود الامتحان غير متوفر</div>';
                const iframe = container.querySelector('iframe');
                if (iframe) {
                    iframe.style.width = '100%';
                    iframe.style.height = '100%';
                    iframe.style.border = '0';
                    iframe.style.minHeight = '500px';
                }
            }
            if (btnPdf) btnPdf.classList.add('hidden');
        } else {
            // Video Mode
            if (this.currentLecture.videoUrl) {
                let url = this.currentLecture.videoUrl;
                if (url.includes('youtu')) {
                    const vidId = url.split('v=')[1]?.split('&')[0] || url.split('/').pop();
                    url = `https://www.youtube.com/embed/${vidId}?rel=0&modestbranding=1`;
                }
                container.innerHTML = `<iframe id="video-frame" src="${url}" frameborder="0" allowfullscreen style="width:100%; height:100%;"></iframe>`;
            } else {
                container.innerHTML = '<div style="display:flex; justify-content:center; align-items:center; height:100%; color:white;">محتوى نصي فقط</div>';
            }

            if (btnPdf) {
                if (this.currentLecture.attachmentUrl) {
                    btnPdf.href = this.currentLecture.attachmentUrl;
                    btnPdf.classList.remove('hidden');
                } else {
                    btnPdf.classList.add('hidden');
                }
            }
        }

        // Hide "Start Exam" button for now as we are embedding it directly
        if (btnExam) btnExam.classList.add('hidden');

        this.nav('player');
    },

    // --- QUIZ RENDERER ---
    renderQuiz(container, exam) {
        // Handle array or object wrapper
        const questions = Array.isArray(exam) ? exam : (exam.questions || []);
        if (!questions.length) {
            container.innerHTML = '<div class="text-white p-8 text-center">لا توجد أسئلة في هذا الامتحان</div>';
            return;
        }

        let currentQ = 0;
        let score = 0;
        let answers = [];

        // Wrapper
        container.innerHTML = `
            <div class="quiz-container fade-in">
                <div class="quiz-header">
                    <span class="text-slate-500">سؤال <span id="q-num">1</span> من ${questions.length}</span>
                    <span class="font-bold text-indigo-600">${this.currentLecture.title}</span>
                </div>
                <div id="quiz-body">
                    <!-- Question Injected Here -->
                </div>
                <div class="quiz-footer">
                    <button id="btn-next" class="btn primary" style="width:auto; margin:0;" onclick="StudentApp.nextQuestion()">التالي</button>
                </div>
            </div>
        `;

        // State attached to App for access in handlers
        this.quizState = { questions, currentQ, score, answers, container };
        this.showQuestion();
    },

    showQuestion() {
        const { questions, currentQ } = this.quizState;
        const q = questions[currentQ];
        const body = document.getElementById('quiz-body');

        document.getElementById('q-num').innerText = currentQ + 1;

        // Render Options (Handle string or object)
        const optionsHtml = (q.options || []).map((opt, i) => {
            const val = typeof opt === 'object' ? (opt.text || opt.value) : opt;
            const display = typeof opt === 'object' ? (opt.text || opt.label || val) : opt;
            return `
            <button class="option-btn" onclick="StudentApp.selectOption(this, '${val}')" data-val="${val}">
                ${display}
            </button>
            `;
        }).join('');

        body.innerHTML = `
            <h3 class="question-text">${q.q || q.question}</h3>
            <div class="options-grid">
                ${optionsHtml}
            </div>
            <div id="feedback-area" class="hidden mt-4 p-4 rounded-lg text-center font-bold animate-bounce-in"></div>
        `;

        // Update Button Text
        const btn = document.getElementById('btn-next');
        btn.innerText = 'تحقق من الإجابة'; // Check Answer
        btn.onclick = () => StudentApp.checkAnswer();

        this.quizState.checked = false;
    },

    selectOption(btn, value) {
        if (this.quizState.checked) return; // Prevent changing after check

        // Deselect all
        document.querySelectorAll('.option-btn').forEach(b => b.classList.remove('selected'));
        // Select clicked
        btn.classList.add('selected');
        this.quizState.selectedAnswer = value;
    },

    checkAnswer() {
        const { questions, currentQ, selectedAnswer } = this.quizState;
        if (!selectedAnswer) return alert('الرجاء اختيار إجابة');
        if (this.quizState.checked) return this.nextQuestion();

        const q = questions[currentQ];
        const isCorrect = selectedAnswer == (q.answer || q.correctAnswer); // Loose equality for numbers/strings

        // Show Feedback
        const feedback = document.getElementById('feedback-area');
        feedback.classList.remove('hidden');

        const options = document.querySelectorAll('.option-btn');
        options.forEach(btn => {
            if (btn.dataset.val == (q.answer || q.correctAnswer)) {
                btn.classList.add('correct');
            }
            if (!isCorrect && btn.dataset.val == selectedAnswer) {
                btn.classList.add('wrong');
            }
        });

        if (isCorrect) {
            feedback.className = 'mt-4 p-4 rounded-lg text-center font-bold bg-green-100 text-green-700';
            feedback.innerHTML = '🎉 إجابة صحيحة! أحسنت يا بطل';
            this.quizState.score++;
        } else {
            feedback.className = 'mt-4 p-4 rounded-lg text-center font-bold bg-red-100 text-red-700';
            feedback.innerHTML = `😔 إجابة خاطئة. الصحيح هو: ${q.answer || q.correctAnswer}`;
            if (q.explanation) {
                feedback.innerHTML += `<br><span class="text-sm font-normal text-slate-600 mt-2 block">${q.explanation}</span>`;
            }
        }

        // Save Answer State
        this.quizState.answers.push({
            question: q.q || q.question,
            answer: selectedAnswer,
            correct: isCorrect,
            correctAnswer: q.answer || q.correctAnswer,
            explanation: q.explanation
        });

        this.quizState.checked = true;
        const btn = document.getElementById('btn-next');
        btn.innerText = (currentQ === questions.length - 1) ? 'إظهار النتيجة' : 'السؤال التالي';
        btn.onclick = () => StudentApp.nextQuestion();
    },

    nextQuestion() {
        const { questions, currentQ } = this.quizState;
        if (currentQ < questions.length - 1) {
            this.quizState.currentQ++;
            this.quizState.selectedAnswer = null;
            this.showQuestion();
        } else {
            this.showResults();
        }
    },

    async showResults() {
        const { score, questions, answers, container } = this.quizState;
        const percentage = Math.round((score / questions.length) * 100);

        // Save Result
        const resultData = {
            studentId: this.user.id,
            studentName: this.user.name,
            examId: this.currentLecture.id,
            examTitle: this.currentLecture.title,
            score: percentage,
            mistakes: answers.filter(a => !a.correct).map(a => ({
                question: a.question,
                wrongAnswer: a.answer,
                correctAnswer: a.correctAnswer,
                explanation: a.explanation
            }))
        };

        try {
            await DataManager.submitExam(resultData);
        } catch (e) { console.error('Save failed', e); }

        // Render Result UI
        container.innerHTML = `
            <div class="quiz-container fade-in">
                <div class="quiz-results">
                    <div class="score-circle">
                        ${percentage}%
                        <div class="score-label">النتيجة</div>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 ${percentage >= 50 ? 'text-green-600' : 'text-red-600'}">
                        ${percentage >= 50 ? 'ممتاز! أحسنت' : 'حاول مرة أخرى'}
                    </h3>
                    <p class="text-slate-600 mb-6">أجبت بشكل صحيح على ${score} من ${questions.length} سؤال</p>
                    
                    <button class="btn primary" onclick="StudentApp.backToCourse()">عودة للدرس</button>
                </div>
            </div>
        `;
    },

    backToCourse() {
        this.nav('course-details');
        document.querySelector('.video-container').innerHTML = '';
    },

    startExam() {
        // Legacy or future expansion
    }
};

document.addEventListener('DOMContentLoaded', () => StudentApp.init());
window.StudentApp = StudentApp;
