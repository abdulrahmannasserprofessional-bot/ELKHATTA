// Firebase Configuration
// To activate Google Sign-In:
// 1. Go to Firebase Console -> Project Settings
// 2. Copy the "firebaseConfig" object
// 3. Paste it below to replace the placeholder
// 4. Enable "Google" in Firebase Console -> Authentication -> Sign-in method

const firebaseConfig = {
    apiKey: "YOUR_API_KEY_HERE",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
window.auth = null;
window.provider = null;

try {
    firebase.initializeApp(firebaseConfig);
    window.auth = firebase.auth();
    window.provider = new firebase.auth.GoogleAuthProvider();
    console.log("Firebase Initialized");
} catch (e) {
    console.warn("Firebase Config missing or invalid. Google Sign-In will be in Mock Mode.");
}
