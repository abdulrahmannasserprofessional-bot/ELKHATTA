/**
 * Data Manager - Shared
 * Reliable connection to Firebase Realtime Database via REST API
 */

const DB_URL = "https://elkhotta-default-rtdb.europe-west1.firebasedatabase.app";

const DataManager = {
    // --- CORE ---
    async _fetch(path, method = 'GET', body = null) {
        const url = `${DB_URL}/${path}.json`;
        const options = { method };
        if (body) {
            options.body = JSON.stringify(body);
            options.headers = { 'Content-Type': 'application/json' };
        }

        try {
            const res = await fetch(url, options);
            if (!res.ok) throw new Error(`Firebase Error: ${res.statusText}`);
            const data = await res.json();

            // Convert Object to Array (if it's a list)
            if (method === 'GET') {
                if (!data) return []; // Return empty array if null/undefined
                if (typeof data === 'object' && !Array.isArray(data)) {
                    // Start of workaround for array-like objects with ID keys
                    return Object.keys(data).map(key => ({
                        ...data[key],
                        id: key // Ensure ID is preserved from key if not in object
                    }));
                }
                return data;
            }
            return data;
        } catch (e) {
            console.error(`API Error (${path}):`, e);
            throw e; // Propagate error for UI handling
        }
    },

    // --- STUDENTS ---
    async getStudents() { return await this._fetch('students'); },

    async getStudentById(id) {
        return await this._fetch(`students/${id}`);
    },

    async saveStudent(student) {
        // Check for duplicates locally first (optimization)
        const all = await this.getStudents();
        const exists = all.find(s => s.phone === student.phone);
        if (exists) return { success: false, message: 'رقم الهاتف مسجل مسبقاً' };

        student.id = Date.now().toString();
        student.joinedAt = new Date().toISOString();
        // Save using ID as key for easier updates
        await this._fetch(`students/${student.id}`, 'PUT', student);
        return { success: true, student };
    },

    async updateStudent(student) {
        if (!student.id) return { success: false, message: 'ID missing' };
        // We only update specific fields, preserving joinedAt and other potential metadata
        await this._fetch(`students/${student.id}`, 'PATCH', student);
        return { success: true };
    },

    async loginStudent(phone) {
        const all = await this.getStudents();
        const student = all.find(s => s.phone === phone);
        if (student) {
            this.setSession(student);
            return { success: true, student };
        }
        return { success: false, message: 'رقم الهاتف غير معروف' };
    },

    async deleteStudent(id) {
        return await this._fetch(`students/${id}`, 'DELETE');
    },

    // --- COURSES ---
    async getCourses() { return await this._fetch('courses'); },

    async saveCourse(course) {
        if (!course.id) {
            course.id = Date.now().toString();
            course.lectures = [];
        } else {
            // If updating, ensure we don't lose lectures if not passed
            const existing = await this.getCourseById(course.id);
            if (existing) {
                course.lectures = existing.lectures || [];
            }
        }
        await this._fetch(`courses/${course.id}`, 'PUT', course);
        return { success: true };
    },

    async getCourseById(id) {
        return await this._fetch(`courses/${id}`);
    },

    async deleteCourse(id) {
        return await this._fetch(`courses/${id}`, 'DELETE');
    },

    // --- CHAPTERS ---
    async addChapter(courseId, title) {
        const course = await this._fetch(`courses/${courseId}`);
        if (!course) throw new Error("Course not found");

        let chapters = course.chapters || [];
        const newChapter = {
            id: Date.now().toString(),
            title: title,
            lectures: [] // Lectures can now be inside chapters
        };
        chapters.push(newChapter);

        await this._fetch(`courses/${courseId}/chapters`, 'PUT', chapters);
        return { success: true };
    },

    async deleteChapter(courseId, chapterId) {
        const course = await this._fetch(`courses/${courseId}`);
        if (!course) throw new Error("Course not found");

        let chapters = course.chapters || [];
        chapters = chapters.filter(c => c.id !== chapterId);

        await this._fetch(`courses/${courseId}/chapters`, 'PUT', chapters);
        return { success: true };
    },

    // --- LECTURES ---
    async addLectureToCourse(courseId, lecture, chapterId = null) {
        const course = await this._fetch(`courses/${courseId}`);
        if (!course) throw new Error("Course not found");

        if (chapterId) {
            // Add to specific chapter
            let chapters = course.chapters || [];
            const chapterIndex = chapters.findIndex(c => c.id === chapterId);
            if (chapterIndex === -1) throw new Error("Chapter not found");

            chapters[chapterIndex].lectures = chapters[chapterIndex].lectures || [];
            chapters[chapterIndex].lectures.push(lecture);
            await this._fetch(`courses/${courseId}/chapters`, 'PUT', chapters);
        } else {
            // Add to root (default)
            let lectures = course.lectures || [];
            lectures.push(lecture);
            await this._fetch(`courses/${courseId}/lectures`, 'PUT', lectures);
        }
        return { success: true };
    },

    async updateLecture(courseId, lecture) {
        // Search in root
        const course = await this._fetch(`courses/${courseId}`);
        let lectures = course.lectures || [];
        let index = lectures.findIndex(l => l.id === lecture.id);

        if (index !== -1) {
            lectures[index] = { ...lectures[index], ...lecture };
            await this._fetch(`courses/${courseId}/lectures`, 'PUT', lectures);
            return { success: true };
        }

        // Search in chapters
        let chapters = course.chapters || [];
        for (let i = 0; i < chapters.length; i++) {
            let chLectures = chapters[i].lectures || [];
            let lIndex = chLectures.findIndex(l => l.id === lecture.id);
            if (lIndex !== -1) {
                chLectures[lIndex] = { ...chLectures[lIndex], ...lecture };
                chapters[i].lectures = chLectures;
                await this._fetch(`courses/${courseId}/chapters`, 'PUT', chapters);
                return { success: true };
            }
        }

        return { success: false, message: 'Lecture not found' };
    },

    async deleteLecture(courseId, lectureId) {
        const course = await this._fetch(`courses/${courseId}`);

        // Try delete from root
        let lectures = course.lectures || [];
        const initialLen = lectures.length;
        lectures = lectures.filter(l => l.id !== lectureId);

        if (lectures.length !== initialLen) {
            await this._fetch(`courses/${courseId}/lectures`, 'PUT', lectures);
            return { success: true };
        }

        // Try delete from chapters
        let chapters = course.chapters || [];
        let found = false;

        chapters = chapters.map(c => {
            const originalLen = c.lectures ? c.lectures.length : 0;
            c.lectures = (c.lectures || []).filter(l => l.id !== lectureId);
            if (c.lectures.length !== originalLen) found = true;
            return c;
        });

        if (found) {
            await this._fetch(`courses/${courseId}/chapters`, 'PUT', chapters);
            return { success: true };
        }

        return { success: false };
    },

    // --- RESULTS ---
    async getAllResults() { return await this._fetch('results'); },

    async submitExam(result) {
        result.id = Date.now().toString();
        result.date = new Date().toISOString();
        await this._fetch(`results/${result.id}`, 'PUT', result);

        // If result has mistakes, log them to 'errors' path for admin analysis
        if (result.mistakes && Array.isArray(result.mistakes)) {
            for (const mistake of result.mistakes) {
                await this._fetch(`errors`, 'POST', {
                    ...mistake,
                    studentName: result.studentName,
                    examTitle: result.examTitle,
                    date: result.date
                });
            }
        }
        return { success: true };
    },

    async deleteResult(id) {
        return await this._fetch(`results/${id}`, 'DELETE');
    },

    // --- ERRORS LOG ---
    async getErrors() { return await this._fetch('errors'); },
    async clearErrors() { return await this._fetch('errors', 'DELETE'); },

    // --- ADMINS ---
    async getAdmins() { return await this._fetch('admins'); },

    // --- ANNOUNCEMENTS ---
    async getAnnouncements() {
        return await this._fetch('announcements');
    },
    async addAnnouncement(ad) {
        await this._fetch(`announcements/${ad.id}`, 'PUT', ad);
    },
    async deleteAnnouncement(id) {
        await this._fetch(`announcements/${id}`, 'DELETE');
    },

    // --- SESSION ---
    setSession(user) {
        sessionStorage.setItem('plan_user', JSON.stringify(user));
    },

    getSession() {
        return JSON.parse(sessionStorage.getItem('plan_user') || 'null');
    },

    logout() {
        sessionStorage.removeItem('plan_user');
        sessionStorage.removeItem('admin_auth');
        window.location.href = '../index.html';
    }
};

window.DataManager = DataManager;
